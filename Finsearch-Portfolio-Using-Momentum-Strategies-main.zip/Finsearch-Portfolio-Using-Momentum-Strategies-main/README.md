# Finsearch-Portfolio-Using-Momentum-Strategies
Finsearch (Summer '23) project on creating a trading portfolio using Momentum strategies.
